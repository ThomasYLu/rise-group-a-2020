# dentate_network
 Dentate gyrus network that can be rendered seizure-prone
